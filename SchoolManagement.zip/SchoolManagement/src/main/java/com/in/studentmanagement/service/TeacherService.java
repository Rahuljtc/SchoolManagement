package com.in.studentmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;

import com.in.studentmanagement.model.Teacher;
import com.in.studentmanagement.repository.TeacherRepository;

import jakarta.persistence.Cacheable;

@Service
public class TeacherService {
	
    @Autowired
    private TeacherRepository teacherRepository;

    // Get all teachers
    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }

    // Get a teacher by ID
    @CacheEvict(value = "teachers", key = "#id")
    public Teacher getTeacherById(Long id) {
        return teacherRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Teacher not found with id: " + id));
    }

    // Save a new teacher
    @CacheEvict(value = "teachers", key = "#teacher.id")
    public Teacher saveTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    // Update an existing teacher
    @CachePut(value = "teachers", key = "#teacher.id")
    public Teacher updateTeacher(Long id, Teacher teacherDetails) {
        Teacher teacher = teacherRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Teacher not found with id: " + id));

        teacher.setName(teacherDetails.getName());
        teacher.setEmail(teacherDetails.getEmail());
        teacher.setSubject(teacherDetails.getSubject());
        teacher.setDepartment(teacherDetails.getDepartment());

        return teacherRepository.save(teacher);
    }

    // Delete a teacher
    @CacheEvict(value = "teachers", key = "#id")
    public void deleteTeacher(Long id) {
        teacherRepository.deleteById(id);
    }
}
