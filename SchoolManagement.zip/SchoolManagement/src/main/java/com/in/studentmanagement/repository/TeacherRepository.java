package com.in.studentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.in.studentmanagement.model.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Long>{

}
