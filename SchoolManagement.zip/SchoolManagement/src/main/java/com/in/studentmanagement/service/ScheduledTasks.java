package com.in.studentmanagement.service;



import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ScheduledTasks {

    // This method runs every 5 seconds
    @Scheduled(fixedRate = 5000)
    public void performTaskEvery5Seconds() {
        System.out.println("Scheduled task executed every 5 seconds");
    }

    // This method runs every day at midnight
    @Scheduled(cron = "0 0 0 * * ?")
    public void performTaskAtMidnight() {
        System.out.println("Scheduled task executed at midnight");
    }

    // This method runs every minute
    @Scheduled(fixedDelay = 60000)
    public void performTaskEveryMinute() {
        System.out.println("Scheduled task executed every minute");
    }

    // This method runs after the application startup
    @Scheduled(initialDelay = 10000, fixedRate = 5000)
    public void performTaskAfterStartup() {
        System.out.println("Scheduled task executed after application startup with a delay");
    }
}

