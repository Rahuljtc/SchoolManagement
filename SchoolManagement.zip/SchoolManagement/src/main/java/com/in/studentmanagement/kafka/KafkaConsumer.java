package com.in.studentmanagement.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {

    // Listen for messages on the specified topic
    @KafkaListener(topics = "teacher-topic", groupId = "my-group")
    public void listen(String message) {
        System.out.println("Received message: " + message);
        // Process the message (e.g., update teacher, log information, etc.)
    }
}

